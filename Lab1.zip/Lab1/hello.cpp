#include <iostream>
/*
 * Cole Barbes --- Lab 1 --- 02/02/2023
 * A simple lab to go over linux command as well as command *line compiling
 */
using namespace std;

int main()
{
    cout<<"Hello World"<<endl;
    return 0;
}
